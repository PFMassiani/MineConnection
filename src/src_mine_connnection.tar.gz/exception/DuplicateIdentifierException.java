package exception;

public class DuplicateIdentifierException extends Exception {
  public DuplicateIdentifierException(String s){
    super(s);
  }
}
