package exception;

public class InvalidIDException extends RuntimeException {
  public InvalidIDException(String s){
    super(s);
  }
}
