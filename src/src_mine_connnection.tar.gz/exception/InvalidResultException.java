package exception;

public class InvalidResultException extends Exception{
  public InvalidResultException(String s){
    super (s);
  }
}
