package exception;

public class NotInAssociationException extends Exception {
  public NotInAssociationException(String s){
    super(s);
  }
}
