package utilisateur;

public class Association extends Utilisateur {

  public Association(int id) {
    super(id);
    // TODO Auto-generated constructor stub
  }

  @Override
  public String getUpdate() {
    // TODO Auto-generated method stub
    return null;
  }

}
